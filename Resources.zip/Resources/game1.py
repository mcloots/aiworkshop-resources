import cv2
import numpy as np
import pygame
import random

# Initialize Pygame
pygame.init()

# Game settings
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 600
GRAVITY = 1
JUMP_HEIGHT = 20
DOUBLE_JUMP_HEIGHT = 25

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)

# Player settings
player_x = 100
player_y = SCREEN_HEIGHT - 60
player_velocity = 0
is_jumping = False
can_double_jump = False

# Obstacles
obstacles = []
obstacle_width = 50
obstacle_height = 50
obstacle_speed = 5

# Pygame screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()

running = True
while running:
    # Pygame event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP and not is_jumping:
                player_velocity = -JUMP_HEIGHT
                is_jumping = True
                can_double_jump = True
            elif event.key == pygame.K_SPACE and not is_jumping:
                player_velocity = -DOUBLE_JUMP_HEIGHT
                is_jumping = True
                can_double_jump = False

    # Pygame game logic
    screen.fill(WHITE)

    # Player movement
    player_y += player_velocity
    player_velocity += GRAVITY

    # Ground collision
    if player_y >= SCREEN_HEIGHT - 60:
        player_y = SCREEN_HEIGHT - 60
        is_jumping = False
        can_double_jump = False

    # Draw player
    pygame.draw.rect(screen, BLACK, (player_x, player_y, 50, 50))

    # Spawn obstacles
    if len(obstacles) == 0 or obstacles[-1][0] < SCREEN_WIDTH - random.randint(300, 500):
        obstacle_y = random.choice([SCREEN_HEIGHT - 60, SCREEN_HEIGHT - 120])
        obstacles.append([SCREEN_WIDTH, obstacle_y])

    # Move obstacles
    for obstacle in obstacles:
        obstacle[0] -= obstacle_speed

    # Remove off-screen obstacles
    obstacles = [obstacle for obstacle in obstacles if obstacle[0] > -obstacle_width]

    # Draw obstacles
    for obstacle in obstacles:
        pygame.draw.rect(screen, RED, (obstacle[0], obstacle[1], obstacle_width, obstacle_height))

    # Collision detection with margin
    collision_margin = 10
    for obstacle in obstacles:
        if (player_x < obstacle[0] + obstacle_width and
                player_x + 50 > obstacle[0] and
                player_y + 50 - collision_margin > obstacle[1]):
            print("Game Over!")
            running = False

    # Update screen
    pygame.display.flip()
    clock.tick(30)

pygame.quit()